package com.quiz.app.simple.mind;

/**
 * Hello world!
 *
 */
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;





public class App extends JFrame implements ActionListener{
    /**
     * 
     */
    JButton button,exit;
    JTextField jname;
    public App(){
        setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/login.jpg"));
        JLabel image = new JLabel(i1);
        image.setBounds(0,0,600,500);
        add(image);

        JLabel heading = new JLabel("Simple Minds");
        heading.setBounds(759,60,300,45);
        heading.setFont(new Font("Viner Hand ITC",Font.BOLD, 40));
        heading.setForeground(new Color(112, 41, 99));
        add(heading);

        JLabel name = new JLabel("Enter Your Name");
        name.setBounds(810,150,300,17);
        name.setFont(new Font("Time New Roman ",Font.BOLD, 20));
        name.setForeground(Color.BLACK);
        add(name);

        jname = new JTextField();
        jname.setBounds(735,200,300,25);
        jname.setFont(new Font("Arial", Font.BOLD,15));
        add(jname);

        button = new JButton("submit");
        button.setBounds(735,250,300,26);
        button.setBackground(new Color(36,160,237));
        button.setForeground(Color.WHITE);
        button.addActionListener(this);
        add(button);

        exit = new JButton("Exit");
        exit.setBounds(735,287,300,26);
        exit.setBackground(new Color(36,160,237));
        exit.setForeground(Color.WHITE);
        exit.addActionListener(this);
        add(exit);
        
        


        getContentPane().setBackground(Color.WHITE);
        setSize(1200,500);
        setLocation(50,100);
        setVisible(true);
    }
   
	public void actionPerformed(ActionEvent e){
        if(e.getSource()==button){
            String name = jname.getText();
            new rules(name);
            setVisible(false);
        } else if (e.getSource()==exit){
                setVisible(false);
        }

    }
    public static void main(String[] args) {
        new App();
    }
}
