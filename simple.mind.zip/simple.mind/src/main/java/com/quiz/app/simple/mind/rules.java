package com.quiz.app.simple.mind;

import javax.swing.JButton;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class rules extends JFrame implements ActionListener{
    String Uname;
    JButton back,start;
    rules(String name){
        Uname = name;
        
        setLayout(null);
        JLabel heading = new JLabel("Welcome "+Uname+" to Simple Minds");
        heading.setBounds(190,20,700,30);
        heading.setFont(new Font("Viner Hand ITC",Font.BOLD, 30));
        heading.setForeground(new Color(112, 41, 99));
        add(heading);
        
        JLabel rule= new JLabel();
        rule.setBounds(10,90,700,350);
        rule.setFont(new Font("Arial",Font.PLAIN, 18));
        rule.setText(
            "<html>"+ 
                "1. You are trained to be a programmer and not a story teller, answer point to point" + "<br><br>" +
                "1. Do not unnecessarily smile at the person sitting next to you, they may also not know the answer" + "<br><br>" +
                "2. You may have lot of options in life but here all the questions are compulsory" + "<br><br>" +
                "3. Crying is allowed but please do so quietly." + "<br><br>" +
                "4. Only a fool asks and a wise answers (Be wise, not otherwise)" + "<br><br>" +
                "5. Do not get nervous if your friend is answering more questions, may be he/she is doing Jai Mata Di" + "<br><br>" +
                "6. Brace yourself, this paper is not for the faint hearted" + "<br><br>" +
                "7. May you know more than what John Snow knows, Good Luck" + "<br><br>" +
            "<html>"
    );
        add(rule);

        back = new JButton("Back");
        back.setBounds(250,500,100,30);
        back.setBackground(new Color(36,160,237));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);

        start = new JButton("Start");
        start.setBounds(400,500,100,30);
        start.setBackground(new Color(36,160,237));
        start.setForeground(Color.WHITE);
        start.addActionListener(this);
        add(start);

        getContentPane().setBackground(Color.white);
        setSize(800,650);
        setLocation(270,10);
        setVisible(true);

    }
    public void actionPerformed(ActionEvent e){
            if(e.getSource() == back){
                setVisible(false);
                new App();

            }else if(e.getSource() == start)
            setVisible(false);
                new Quiz(Uname);
                
            }
    
    public static void main(String[] args) {
        new rules("user");
    }
}