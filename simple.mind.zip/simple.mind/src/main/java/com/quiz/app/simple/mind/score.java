package com.quiz.app.simple.mind;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class score extends JFrame implements ActionListener{
    JButton play, exit;
    score(String name,int score){ {
        

        JLabel heading = new JLabel("Thank You "+name+" For Playing Simple Minds Quiz");
        heading.setBounds(20,50,800,30);
        heading.setFont(new Font("Viner Hand ITC",Font.BOLD, 30));
        heading.setForeground(new Color(112, 41, 99));
        add(heading);

        
        JLabel heading2 = new JLabel( name +" YOUR SCORE IS : "+ score +"/"+100);
        heading2.setBounds(190,160,700,30);
        heading2.setFont(new Font("Time New Roman",Font.BOLD, 30));

        play = new JButton("Play Again");
        play.setBounds(250,240,100,30);
        play.setBackground(new Color(36,160,237));
        play.setForeground(Color.WHITE);
        play.addActionListener(this);
        add(play);

        exit = new JButton("Exit");
        exit.setBounds(400,240,100,30);
        exit.setBackground(new Color(36,160,237));
        exit.setForeground(Color.WHITE);
        exit.addActionListener(this);
        add(exit);
        
        add(heading2);
        setLayout(null);
        getContentPane().setBackground(Color.white);
        setSize(800,350);
        setLocation(270,100);
        setVisible(true);
    }
}
public void actionPerformed(ActionEvent e){
    if (e.getSource()==play){
        setVisible(false);
        new App();
    }else if(e.getSource()== exit){
        setVisible(false);
    }

}
    public static void main(String[] args) {
        new score("user",0);
    }
}
